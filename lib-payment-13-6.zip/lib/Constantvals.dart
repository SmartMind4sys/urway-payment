class Constantvals
{
  static var termId;

  static var termpass;
  static var merchantkey;
  static var requrl;
  static var appinitiateTrxn=true;
  static const double padding = 16.0;
  static const double avatarRadius = 66.0;
  static const double marginTop = 26.0;

}